package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Department;
import com.example.demo.service.DepartmentService;

@RestController
public class DepartmentController {
	  
      @Autowired 
      DepartmentService ds1;
      @PostMapping("/departments")// passing values post is used
      public Department saveDepartment(@RequestBody Department department) {//while passing the values we pass in request body json
    	// here Department is an Object not an primitive type
  		return ds1.saveDepartment(department);
  	}
}
