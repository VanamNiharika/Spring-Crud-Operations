package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Department;
import com.example.demo.repository.DepartmentRepository;
@Service
public class DepartmentServiceImpl implements DepartmentService {
	@Autowired
	DepartmentRepository dr1;

	@Override
	public Department saveDepartment(Department department) {
		// TODO Auto-generated method stub
		return dr1.save(department); //specific methods (built in methods
	}
 
}
